<?php
class HolidayService {
    private $holidays = [
        '2026-01-01',
        '2026-05-01',
        '2026-10-01'
    ];

    public function isHoliday($date) {
        return in_array($date, $this->holidays);
    }
}
