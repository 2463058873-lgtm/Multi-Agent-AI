<?php
require_once __DIR__ . '/../agents/InputParsingAgent.php';
require_once __DIR__ . '/../agents/NLPAgent.php';
require_once __DIR__ . '/../agents/RuleValidationAgent.php';
require_once __DIR__ . '/../agents/DecisionAgent.php';
require_once __DIR__ . '/../repositories/ApprovalRepository.php';

class ApprovalWorkflowService {
    private $inputAgent;
    private $nlpAgent;
    private $validationAgent;
    private $decisionAgent;
    private $repository;

    public function __construct() {
        $this->inputAgent = new InputParsingAgent();
        $this->nlpAgent = new NLPAgent();
        $this->validationAgent = new RuleValidationAgent();
        $this->decisionAgent = new DecisionAgent();
        $this->repository = new ApprovalRepository();
    }

    public function execute($text) {
        $parsed = $this->inputAgent->parse($text);

        $semanticData = $this->nlpAgent->analyze($parsed);

        $errors = $this->validationAgent->validate($semanticData);

        $decision = $this->decisionAgent->decide($errors);

        $finalData = array_merge($semanticData, $decision);

        $this->repository->save($finalData);

        return $finalData;
    }
}
