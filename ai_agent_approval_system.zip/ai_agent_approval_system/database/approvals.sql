CREATE TABLE approvals (
    id INT PRIMARY KEY AUTO_INCREMENT,
    type VARCHAR(50),
    request_text TEXT,
    request_date DATE,
    start_time TIME,
    end_time TIME,
    status VARCHAR(50),
    risk_level VARCHAR(50),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
