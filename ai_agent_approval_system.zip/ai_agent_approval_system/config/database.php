<?php
class Database {
    private $host = 'localhost';
    private $dbname = 'ai_approval';
    private $username = 'root';
    private $password = '123456';

    public function connect() {
        return new PDO(
            "mysql:host={$this->host};dbname={$this->dbname};charset=utf8",
            $this->username,
            $this->password
        );
    }
}
