<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>AI 智能审批系统</title>
</head>
<body>

<h2>AI 智能审批系统</h2>

<textarea id="text" rows="5" cols="50"></textarea>
<br><br>

<button onclick="submitApproval()">提交审批</button>

<pre id="result"></pre>

<script>
async function submitApproval() {
    const text = document.getElementById('text').value;

    const response = await fetch('api.php', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({ text })
    });

    const result = await response.json();

    document.getElementById('result').innerText =
        JSON.stringify(result, null, 4);
}
</script>

</body>
</html>
