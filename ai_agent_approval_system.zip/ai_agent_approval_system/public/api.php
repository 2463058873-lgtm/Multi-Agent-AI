<?php
header('Content-Type: application/json');

require_once __DIR__ . '/../services/ApprovalWorkflowService.php';

$input = json_decode(file_get_contents('php://input'), true);

$text = $input['text'] ?? '';

$workflow = new ApprovalWorkflowService();

$result = $workflow->execute($text);

echo json_encode($result, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);
