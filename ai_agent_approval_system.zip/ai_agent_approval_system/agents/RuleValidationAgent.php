<?php
require_once __DIR__ . '/../services/HolidayService.php';

class RuleValidationAgent {
    private $holidayService;

    public function __construct() {
        $this->holidayService = new HolidayService();
    }

    public function validate($data) {
        $errors = [];

        if ($this->holidayService->isHoliday($data['request_date'])) {
            $errors[] = '当前申请日期属于节假日';
        }

        if ($data['type'] == 'unknown') {
            $errors[] = '无法识别审批类型';
        }

        return $errors;
    }
}
