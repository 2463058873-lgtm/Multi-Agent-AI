<?php
class InputParsingAgent {
    public function parse($text) {
        $result = [
            'type' => 'unknown',
            'hour' => null,
            'text' => $text
        ];

        preg_match('/(加班|请假|调休)/u', $text, $type);
        preg_match('/(\d{1,2})点/u', $text, $hour);

        if (!empty($type[1])) {
            $result['type'] = $type[1];
        }

        if (!empty($hour[1])) {
            $result['hour'] = $hour[1];
        }

        return $result;
    }
}
