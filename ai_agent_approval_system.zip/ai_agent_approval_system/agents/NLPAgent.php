<?php
class NLPAgent {
    public function analyze($parsed) {
        return [
            'type' => $parsed['type'],
            'request_text' => $parsed['text'],
            'request_date' => date('Y-m-d'),
            'start_time' => '18:00:00',
            'end_time' => ($parsed['hour'] ?? 22) . ':00:00'
        ];
    }
}
