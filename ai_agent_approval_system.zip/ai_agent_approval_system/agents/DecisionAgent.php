<?php
class DecisionAgent {
    public function decide($errors) {
        if (empty($errors)) {
            return [
                'status' => 'approved',
                'risk_level' => 'low',
                'message' => '自动审批通过'
            ];
        }

        return [
            'status' => 'manual_review',
            'risk_level' => 'medium',
            'message' => implode(',', $errors)
        ];
    }
}
