<?php
require_once __DIR__ . '/../config/database.php';

class ApprovalRepository {
    private $pdo;

    public function __construct() {
        $database = new Database();
        $this->pdo = $database->connect();
    }

    public function save($data) {
        $sql = "
            INSERT INTO approvals
            (
                type,
                request_text,
                request_date,
                start_time,
                end_time,
                status,
                risk_level
            )
            VALUES
            (
                :type,
                :request_text,
                :request_date,
                :start_time,
                :end_time,
                :status,
                :risk_level
            )
        ";

        $stmt = $this->pdo->prepare($sql);

        $stmt->execute([
            ':type' => $data['type'],
            ':request_text' => $data['request_text'],
            ':request_date' => $data['request_date'],
            ':start_time' => $data['start_time'],
            ':end_time' => $data['end_time'],
            ':status' => $data['status'],
            ':risk_level' => $data['risk_level']
        ]);
    }
}
